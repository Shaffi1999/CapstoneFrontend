import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cart } from '../cart';
import { RegisterationService } from '../registeration.service';

@Component({
  selector: 'app-viewcart',
  templateUrl: './viewcart.component.html',
  styleUrls: ['./viewcart.component.css']
})
export class ViewcartComponent implements OnInit {
cartitems :Cart[];
price:Number;

userId=localStorage.getItem("userData");
  constructor(private service:RegisterationService,private route:Router) { }

  ngOnInit(): void {
    this.cartItems();
    this.service.calculateTotalPrice(Number(this.userId)).subscribe(
      (data) =>
      {
        this.price=data,
        console.log(data)
      } ,
     (error) => console.log(error)
      );
  }

  cartItems()
  {
    this.service.getItemsByUserId(Number(this.userId)).subscribe(
      (data) => {
        this.cartitems=data,
        console.log(data)
      }
        ,
      (error)=>console.log(error)
    );
  }

  totalPrice()
  {
      this.service.calculateTotalPrice(Number(this.userId)).subscribe(
        (data) =>
        {
          this.price=data,
          console.log(data)
        } ,
       (error) => console.log(error)
        );
      
    
  }
  deleteItem(id:Number)
  {
    this.service.deleteItem(id).subscribe(
      
      (data) => 
      {
        console.log(data);
        this.cartItems();
       this.totalPrice();
      },

      (error) => console.log(error)
    )
  }
  goToItems()
  {
    this.route.navigate(['/loginsuccess']);
  }

  ordercomplete()
  {
    this.route.navigate(['/order']);
  }
}
